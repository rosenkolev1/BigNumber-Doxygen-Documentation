var searchData=
[
  ['stringmanip_0',['StringManip',['../class_string_manip.html',1,'']]],
  ['stringmaniptests_1',['StringManipTests',['../class_string_manip_tests.html',1,'']]]
];
