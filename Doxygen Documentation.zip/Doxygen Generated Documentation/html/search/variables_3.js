var searchData=
[
  ['init_5fcapacity_0',['INIT_CAPACITY',['../class_big_number.html#a021dbef8899fbf5bc8dbab2ee79be2fd',1,'BigNumber']]]
];
