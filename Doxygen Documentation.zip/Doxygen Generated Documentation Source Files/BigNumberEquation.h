#pragma once

#include "BigNumberExpression.h"

/// <summary>
/// This class holds equations whose answer can be calculated if they are simple enough or validated with BigNumber. This class can also randomly generate valid equations as well.
/// The random generation works by randomly creating an equation template, which has all of the operators and brackets but all the numbers are replaced with x and the unknowns are replaced with U.
/// The numbers are then also randomly chosen to fill those x's and that is how you get a randomly generated equation.
/// The percent operator is not allowed for equations because I decided it isn't. And also because I thought it would cause problems like x%5 = 0, which would have an infinite set of answers.
/// But then again, if the % operator isn't tied to the unknowns, then it's not a problem. For example: x + 5%3 = 3 ==> x=-1. Easy.
/// I actually did just that when I stupidly realised that there is no reliable way I can solve an expression where the unknowns are tied to division because of many error, since BigNumber is a whole number and the division of whole numbers generally doesn't return a whole number.
/// So I made it so that an equation can only be solved if the division operator isn't tied to the unknown. I haven't done this for percent, however...
/// For example: the equation can solve x*12312312412*(14125120124-12412+1234123)*213412 = (1212541*(123120321+123123))*(1234124-1000)...
/// But it cannot solve x/5 = 25; For this, the function(solveEquation) throws an error saying that the equation is too complicated. And it kind of is. Because BigNumber is a whole number 26/5 would also return 5.
/// And so would 27, and 28 and 29...
/// Also, the class cannot solve equations which contain more than one unknown. For example: x*5+x=4;
/// </summary>
class BigNumberEquation
	:public BigNumberExpressionCommon
{
public:
	///Exception messages
	static constexpr const char* EQUATION_INVALID_EXCEPTION = "Invalid Equation!";
	static constexpr const char* EQUATION__SOLVE_TOOCOMPLEX_EXCEPTION = "Equation is too complex for me to solve";
	static constexpr const char* EQUATION__SOLVE_TIEDTODIVISION_EXCEPTION = "The unknown is tied to division, so I can't solve this equation, sorry!";
	static constexpr const char* EQUATION__SOLVE_NOTWHOLE_EXCEPTION = "Not whole number solution";
	static constexpr const char* EQUATION__SOLVE_EVERYANSWER_EXCEPTION = "Every x is an answer to the equation";
	static constexpr const char* EQUATION__SOLVE_NOANSWER_EXCEPTION = "No answer for this equation";

	//All of the valid expression operators. This is used sometimes when checking for things.
	static constexpr const char* EQUATION_OPERATORS = "+-*/";

private:

	/// <summary>
	/// This is the equation.
	/// </summary>
	char* equation;
	/// <summary>
	/// This is the capacity of the array that holds the equation
	/// </summary>
	size_t capacity;

	/// <summary>
	/// This function copies other. It is used in both the =operator function and the constructor. The difference is that the copy constructor calls the default constructor beforehand.
	/// Otherwise, the copy function will try to delete the number array before it copies the number array of other, which will result in an error because the number array isn't even initialized in the first place.
	/// </summary>
	/// <param name="other"></param>
	void copy(const BigNumberEquation& other);

	/// <summary>
	/// This function randomly generates the count of unknowns for a randomly generated equation based on a seed that is a random computer number generated with rand().
	/// The expected values of seed are 0-49
	/// </summary>
	/// <param name="seed"></param>
	/// <returns></returns>
	int generateCountOfX(int seed);

public:

	///Big 4
	BigNumberEquation();
	BigNumberEquation(const BigNumberEquation& other);
	BigNumberEquation& operator= (const BigNumberEquation& other);
	~BigNumberEquation();

	///This constructor creates a BigNumberEquation with the given equation. If the equation is invalid, it throws an error
	BigNumberEquation(const char* equation);

	///Check for equation validity. Excluding if the equation has a valid whole number solution or not, or if it throws a divide by zero exception because there is division by 0 in it.
	bool isValidEquation(const char* equation = nullptr) const;

	///Get the answer to an equation.
	///If the answer is not a whole number, the function throws an error. For example: x*2=91;
	/// If every x is an answer to the equation, it throwns an error. For example: x*(10+5-15)=0;
	/// If there is no answer to the equation, it throws an error. For example: x*(10+5-15)=3;
	/// If the equation contains a division by 0 in it somewhere, it throws an error. For example: x + 100/(10+5-15)=3;
	/// If the equation contains a division that is tied to the unknown, then it throws an error that the equation is too complex to be solved. For example: x/5=25;
	/// If the equation contains more than 1 unknown, then it throws an error that the equation is too complex to be solved. For example: x*5=x*32+17;
	/// If the equation param is nullptr, then the function uses this->equation. If it isn't, then the function uses the equation param.
	/// This is used because sometimes, for test cases specifically, it is somewhat more convenient to just use the function like it's a static function and have it use something else instead of the object caller's equation.
	/// But other times, it is exactly the object caller's equation that needs to be used.
	BigNumber solveEquation(const char* equation = nullptr);

	///Fill the numbers in an equation template. I.e., in the equation template, replace the x with the numbers and the U(unknown) with x.
	char* generateFromTemplate(const char* expressionTemplate, size_t maxUnknown = 3);

	///Generate a random equation, where the left side and the right side can contain only the given operators. totalUnknown should be at most =maxUnknownPerSide, otherwise, throw error!
	void generateEquation(const char* leftSideAllowedOperators, const char* rightSideAllowedOperators, size_t maxUnknownPerSide = 3, size_t totalUnknown = 6);

	///Generate a random equation. totalUnknown should be at most =maxUnknownPerSide, otherwise, throw error!
	///Works by calling the other overload of this function with the EQUATION_OPERATORS constant
	void generateEquation(size_t maxUnknownPerSide = 3, size_t totalUnknown = 6);

	///Get equation as read-only
	const char* getEquation() const;
	///Set equation
	void setEquation(const char* equation);

	///Get the right expression(the expression to the right of the = sign) as read-only
	const char* getRightExpression() const;

	///Get the left expression(the expression to the left of the = sign), as read-only
	const char* getLeftExpression() const;

	///Get equation template
	/// If the equation param is nullptr, then the function uses this->equation. If it isn't, then the function uses the equation param.
	/// This is used because sometimes, for test cases specifically, it is somewhat more convenient to just use the function like it's a static function and have it use something else instead of the object caller's equation.
	/// But other times, it is exactly the object caller's equation that needs to be used.
	char* getEquationTemplate(const char* equation = nullptr) const;

	///Reading and outputting equation to console
	friend std::istream& operator>> (std::istream& is, BigNumberEquation& equation);
	friend std::ostream& operator<< (std::ostream& os, BigNumberEquation& equation);

	///Reading an equation to text file. When reading, read an expression per line
	friend std::ifstream& operator>> (std::ifstream& is, BigNumberEquation& equation);
	///Outputting equations to text file. When outputting, output an equation to one line and then add "The answer to the equation: {answer}", where {answer} is the answer to the equation or, if it throws an error for some reason, it prints that out instead.
	friend std::ofstream& operator<< (std::ofstream& os, BigNumberEquation& equation);
};

