﻿// Project.StringManipulation.cpp : This file contains the 'main' function. Program execution begins and ends there.
//

#include <iostream>
#include "StringManip.h"
#include "StringManipTests.h"

/// <summary>
/// This is the main function of the StringManip project. The program starts from here when the StringManip project is selected as the startup project. That happens when I have implemented a new function for StringManip and I need to test it.
/// This function runs all the tests for StringManip.
/// </summary>
/// <returns></returns>
int main()
{
    StringManipTests::runTests();
}

