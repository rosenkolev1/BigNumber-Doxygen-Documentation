#pragma once
#include <iostream>

/// <summary>
/// This class holds all of the tests for BigNumberEquation and it's functionality.
/// The ostream os parameter that exists for every function allows the test outputs to be stored to a file instead of just printed to the console.
/// Most of the function names describe well enough what the function is supposed to be testing.
/// When thinking of test cases for different tests, I tried to implement test cases that would hit every or at least most possible edge cases.
/// </summary>
class BigNumberEquationTests
{
public:
	/// <summary>
	/// This is the output file name to which to output the tests if the user chooses to output them to a text file instead of to the console
	/// </summary>
	static constexpr const char* OUTPUTFILE_NAME = "BugNumberEquation_Tests_Diagnostics.txt";

	static void equationBig4Tests(std::ostream& os);

	static void equationIsValidTests(std::ostream& os);

	static void solveEquationTests(std::ostream& os);

	static void generateEquationTests(std::ostream& os);

	static void readFromAndWriteToConsoleTests();

	static void readFromAndWriteToFileTests(std::ostream& os);

	/// <summary>
	/// This is the master function. This runs all of the other functions when called. It is called once in main
	/// </summary>
	/// <param name="os"></param>
	static void runTests(std::ostream& os);
};

