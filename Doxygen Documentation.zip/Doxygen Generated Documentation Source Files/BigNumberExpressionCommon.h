#pragma once

/// <summary>
/// This class hold functions that are needed for the random generation of equations and expression. So I made this class the parent class of those 2 classes. I could have made this class abstract but fuck it. It's not abstract as of now.
/// I made the functions virtual as well in case I wanted to make something have a higher/lower chance of happening inside equations than it happens inside expressions.
/// The replaceNumbers function is also cool and used in both of the class, so I added it as well.
/// </summary>
class BigNumberExpressionCommon
{
protected:
	///Randomly generate an operator from a seed, which is a random number generated with rand().
	///The expected seed is between 0-4 by default. This default is used by the expressions class.
	//0-4 for expression
	virtual char generateOperator(int seed) const;

	///Randomly generate an opening bracket from a seed, which is a random number generated with rand().
	///The expected seed is between 0-9 by default. This default is used by the expressions class.
	//0-9 for expression
	virtual char generateOpeningParenthesis(int seed) const;

	///Randomly choose a sign from a seed, which is a random number generated with rand().
	///The expected seed is between 0-14 by default. This default is used by the expressions class.
	//0-14 for expression
	virtual int generateSign(int seed) const;

	///Randomly choose a digits count from a seed, which is a random number generated with rand().
	///The expected seed is between 0-50 by default. This default is used by the expressions class.
	//0-50 for expression
	virtual size_t generateDigitsCount(int seed) const;

	///Replace all the numbers in the expression with something else
	virtual char* replaceNumbers(const char* expression, const char* replacement) const;
};

