#pragma once
#include<iostream>
#include<fstream>

/// <summary>
/// This class holds all of the tests for BigNumberExpression and it's functionality.
/// The ostream os parameter that exists for every function allows the test outputs to be stored to a file instead of just printed to the console.
/// Most of the function names describe well enough what the function is supposed to be testing.
/// When thinking of test cases for different tests, I tried to implement test cases that would hit every or at least most possible edge cases.
/// </summary>
class BigNumberExpressionTests
{
public:
	/// <summary>
	/// This is the output file name to which to output the tests if the user chooses to output them to a text file instead of to the console
	/// </summary>
	static constexpr const char* OUTPUTFILE_NAME = "BugNumberExpressions_Tests_Diagnostics.txt";

	static void expressionBig4Tests(std::ostream& os);

	static void expressionIsValidTests(std::ostream& os);
		   
	static void solveExpressionNoParenthesis_SingleNumberTests(std::ostream& os);
		   
	static void solveExpressionNoParenthesis_AdditionAndMinusTests(std::ostream& os);
		   
	static void solveExpressionNoParenthesis_MultiplyTests(std::ostream& os);
		   
	static void solveExpressionNoParenthesis_DivideTests(std::ostream& os);
		   
	static void solveExpressionNoParenthesis_PercentTests(std::ostream& os);
		   
	static void solveExpressionNoParenthesisTests(std::ostream& os);
		   
	static void solveExpressionParenthesis_SingleNumberTests(std::ostream& os);
		   
	static void solveExpressionParenthesis_AdditionAndMinusTests(std::ostream& os);
		   
	static void solveExpressionParenthesis_DivideTests(std::ostream& os);
		   
	static void solveExpressionParenthesis_MultiplyTests(std::ostream& os);
		   
	static void solveExpressionParenthesis_PercentTests(std::ostream& os);
		   
	static void solveExpressionParenthesisTests(std::ostream& os);
		   
	static void generateExpressionTemplateTests(std::ostream& os);

	static void generateExpressionTests(std::ostream& os);

	//Operator tests
	static void comparativeOperatorsTests(std::ostream& os);

	static void operatorSumTests(std::ostream& os);

	static void operatorSumAndEqualsTests(std::ostream& os);

	static void operatorMinusTests(std::ostream& os);

	static void operatorMinusAndEqualsTests(std::ostream& os);

	static void operatorMultiplyTests(std::ostream& os);

	static void operatorMultiplyAndEqualsTests(std::ostream& os);

	static void operatorDivideTests(std::ostream& os);

	static void operatorDivideAndEqualsTests(std::ostream& os);

	static void operatorPercentTests(std::ostream& os);

	static void operatorPercentAndEqualsTests(std::ostream& os);

	//Console and file writing and reading tests
	static void readFromAndWriteToConsoleTests();

	static void readFromAndWriteToFileTests(std::ostream& os);

	/// <summary>
	/// This is the master function. This runs all of the other functions when called. It is called once in main
	/// </summary>
	/// <param name="os"></param>
	static void runTests(std::ostream& os);
};


