#pragma once

/// This class holds all of the tests for StringManip and it's functionality.
/// Most of the function names describe well enough what the function is supposed to be testing.
/// When thinking of test cases for different tests, I tried to implement test cases that would hit every or at least most possible edge cases.
class StringManipTests
{
public:
	//Helper functions for doing tests
    static void printOutResultStringsFromSplitStringTest(char** strings, size_t numberOfStrings);

	static void printOutStringsFromArray(char** strings, size_t numberOfStrings);

	//Actual tests functions
	static void splitByCharTests();

	static void splitByStringTests();

	static void splitStringManyTests();

	static void stringContainsTests();

	static void replaceAllTests();

	static void replaceFirstTests();

	static void replaceFromTests();

	static void findIndexTests();

	static void findIndexLastTests();

	static void arraysOfStringsAreEqualTests();

	static void getUniqueTests();

	static void getFromTests();

	static void getReversedTests();

	static void countOfTests();

	static void countOfManyTests();

	/// <summary>
	/// This is the master function. This runs all of the other functions when called. It is called once in main(main of StringManip project, not of BigNumber project)
	/// </summary>
	/// <param name="os"></param>
	static void runTests();
};

