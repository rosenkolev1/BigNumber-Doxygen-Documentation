#pragma once
#include "BigNumber.h"
#include <iostream>
#include <fstream>

/// <summary>
/// This class holds all of the tests for BigNumber and it's functionality.
/// The ostream os parameter that exists for every function allows the test outputs to be stored to a file instead of just printed to the console.
/// Most of the function names describe well enough what the function is supposed to be testing.
/// When thinking of test cases for different tests, I tried to implement test cases that would hit every or at least most possible edge cases.
/// </summary>
class BigNumberTests
{
private:
	/// <summary>
	/// A test template for generating text for operator> tests 
	/// </summary>
	/// <param name="testTitle"></param>
	/// <param name="textDescription"></param>
	/// <param name="bigNumber1"></param>
	/// <param name="bigNumber2"></param>
	/// <param name="newLine"></param>
	/// <param name="os"></param>
	static void OperatorGreaterThanTestTemplate(const char testTitle[], const char textDescription[],
		const BigNumber& bigNumber1, const BigNumber& bigNumber2, bool newLine, std::ostream& os);
	/// <summary>
	/// A test template for generating text for operator>= tests 
	/// </summary>
	/// <param name="testTitle"></param>
	/// <param name="textDescription"></param>
	/// <param name="bigNumber1"></param>
	/// <param name="bigNumber2"></param>
	/// <param name="newLine"></param>
	/// <param name="os"></param>
	static void OperatorGreaterThanOrEqualsTestTemplate(const char testTitle[], const char textDescription[],
		const BigNumber& bigNumber1, const BigNumber& bigNumber2, bool newLine, std::ostream& os);

public:
	/// <summary>
	/// This is the output file name to which to output the tests if the user chooses to output them to a text file instead of to the console
	/// </summary>
	static constexpr const char* OUTPUTFILE_NAME = "BugNumber_Tests_Diagnostics.txt";

	static void ConstructorAndCopyAndAssignTests(std::ostream& os);
	static void ReadingOperatorTests();
	static void EqualsAndNotEqualsTests(std::ostream& os);
	static void OperatorGreaterThanTests(std::ostream& os);
	static void OperatorGreaterThanOrEqualsTests(std::ostream& os);
	static void OperatorLessThanTests(std::ostream& os);
	static void OperatorLessThanOrEqualsTests(std::ostream& os);

	static void OperatorSumTests(std::ostream& os);
	static void OperatorSumAndEqualsTests(std::ostream& os);
	static void OperatorMinusTests(std::ostream& os);
	static void OperatorMinusAndEqualsTests(std::ostream& os);

	static void OperatorIncrementTests(std::ostream& os);
	static void OperatorDecrementTests(std::ostream& os);

	static void OperatorMultiplyTests(std::ostream& os);
	static void OperatorMultiplyAndEqualsTests(std::ostream& os);

	static void OperatorDivideTests(std::ostream& os);
	static void OperatorDivideAndEqualsTests(std::ostream& os);

	static void OperatorPercentTests(std::ostream& os);
	static void OperatorPercentAndEqualsTests(std::ostream& os);

	///Special division and percent operator memory leak tests. I used this when I was testing if I am deleting all of the dynamic memory from the divideAndReturn and operator/ and operator% functions.
	///It took me a long time to figure out how to delete the unneccessary dynamic data without also deleting the data that I needed to return at the same time.
	static void OperatorDivideAndPercentMemoryLeakTests();
	///Tests from my assistants Pesho and Lubo from OOP practicum. The BigNumber implementation was originally a homework from them. They gave us some test cases to test the functionality so I used them as well
	static void PeshoAndLuboTests(std::ostream& os);
	///Tests for copying shit correctly without access violation reading exceptions or memory leaks.
	static void SpecialTests(std::ostream& os);

	static void getNumberTests(std::ostream& os);
	static void getNumberRawTests(std::ostream& os);

	///Tests for getNumber memory leak. I had a problem with memory leak from that function so I made this to test it out and eventually solve it.
	static void getNumberMemoryLeakTest();

	/// <summary>
	/// This is the master function. This runs all of the other functions when called. It is called once in main
	/// </summary>
	/// <param name="os"></param>
	static void runTests(std::ostream& os);
};

