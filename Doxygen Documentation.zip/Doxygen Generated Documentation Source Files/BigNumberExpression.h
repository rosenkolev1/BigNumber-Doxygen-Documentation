#pragma once
#include "BigNumber.h"
#include "BigNumberExpressionCommon.h"
#include <ostream>
#include <fstream>

/// <summary>
/// This class holds expressions which can be calculated and, or validated with BigNumber. This class can also randomly generate valid expressions as well.
/// The random generation works by randomly creating an expression template, which has all of the operators and brackets but all the numbers are replaced with x.
/// The numbers are then also randomly chosen to fill those x's and that is how you get a randomly generated expression.
/// </summary>
class BigNumberExpression
	:public BigNumberExpressionCommon
{
public:
	///Check if the expression contains +++, ++-, +-+, +--, -++, -+-, --+, ---. If it does, then it is invalid.
	///Check if the expression contains: **, */, *%, /*, //, /%, %*, %/, %%. If it does, then it is invalid.
	///Check if the expression contains: +*, -*, +/, -/, +%, -%. If it does, then it is invalid.
	///Check if the expression contains: +), -), *), /), %), (). If it does, then it is invalid.
	
	/// These are exception messages. I made them constant because some of the test cases check for and expect a function to throw an error. 
	/// So I check if the thrown error has an error message that is expected by using these constants.
	static constexpr const char* EXPRESSION_DIVIDEBYZERO_EXCEPTION = "DIVISION BY 0 IS NOT ALLOWED!";
	// These are exception messages. I made them constant because some of the test cases check for and expect a function to throw an error. 
	/// So I check if the thrown error has an error message that is expected by using these constants.
	static constexpr const char* EXPRESSION_PERCENTBYZERO_EXCEPTION = "PERCENT BY 0 IS NOT ALLOWED!";
	// These are exception messages. I made them constant because some of the test cases check for and expect a function to throw an error. 
	/// So I check if the thrown error has an error message that is expected by using these constants.
	static constexpr const char* EXPRESSION_INVALID_EXCEPTION = "This expression isn't valid";

	//All of the valid expression operators. This is used sometimes when checking for things.
	static constexpr const char* EXPRESSION_OPERATORS = "+-*/%";
	//All of the valid expression symbols which are not digits. This is used sometimes when check for things.
	static constexpr const char* EXPRESSION_NOTDIGIT = "+-*/%()";

	static const int EXPRESSION_FORBIDDEN_STRINGS_COUNT = 32;
	///FORBIDDEN STRINGS CONSTANT
	static const constexpr char* EXPRESSION_FORBIDDEN_STRINGS[32] =
	{
		"+++",
		"++-",
		"+-+",
		"+--",
		"-++",
		"-+-",
		"--+",
		"---",
		"**",
		"*/",
		"*%",
		"/*",
		"//",
		"/%",
		"%*",
		"%/",
		"%%",
		"+*",
		"-*",
		"+/",
		"-/",
		"+%",
		"-%",
		"+)",
		"-)",
		"*)",
		"/)",
		"%)",
		"(*",
		"(/",
		"(%",
		"()"
	};
private:

	/// <summary>
	/// This is the expression array.
	/// </summary>
	char* expression;
	/// <summary>
	/// This is the capacity of the array that holds the expression
	/// </summary>
	size_t capacity;

	/// <summary>
	/// This function copies other. It is used in both the =operator function and the constructor. The difference is that the copy constructor calls the default constructor beforehand.
	/// Otherwise, the copy function will try to delete the number array before it copies the number array of other, which will result in an error because the number array isn't even initialized in the first place.
	/// </summary>
	/// <param name="other"></param>
	void copy(const BigNumberExpression& other);

	/// <summary>
	/// This function is used in the evaluteExpression function. When 2 numbers have been operated on (i.e. they have been divide, subtracted etc...) then we replace those numbers with the result in the expression. 
	/// We then try to calculate the expression again by removing all the operators and numbers one by one until there is a single number left that is the result of the expression.
	/// This function may not be needed anymore or it may be outdated after the expansion of the StringManip library. But I don't care, it works and I don't want to change it.
	/// </summary>
	/// <param name="numbers"></param>
	/// <param name="countOfNumbers"></param>
	/// <param name="firstIndex"></param>
	/// <param name="resultNumber"></param>
	/// <returns></returns>
	BigNumber* replaceNumbersFromCalculation(BigNumber* numbers, size_t& countOfNumbers, size_t firstIndex, BigNumber* resultNumber) const;
	/// <summary>
	/// This function is used in the evaluteExpression function. When 2 numbers have been operated on (i.e. they have been divide, subtracted etc...) then we replace those numbers with the result in the expression. 
	/// We then try to calculate the expression again by removing all the operators and numbers one by one until there is a single number left that is the result of the expression.
	/// This function may not be needed anymore or it may be outdated after the expansion of the StringManip library. But I don't care, it works and I don't want to change it.
	/// </summary>
	/// <param name="operators"></param>
	/// <param name="index"></param>
	void replaceOperatorsFromCalculation(char* operators, size_t index) const;

public:

	///Big 4

	BigNumberExpression();
	BigNumberExpression(const BigNumberExpression& other);
	~BigNumberExpression();
	BigNumberExpression& operator=(const BigNumberExpression& other);

	/// <summary>
	/// Copies the expression param into the expression field while also setting the capacity. I.e, creates a BigNumberExpression with the expression param.
	/// If the expression is invalid, it throws an error.
	/// </summary>
	/// <param name="expression"></param>
	BigNumberExpression(const char* expression);

	///Get the equation as read-only
	const char* getExpression() const;

	///Set the equation. This doesn't just reassign the pointer. It makes a deep copy of expression that is assigned to this->expression
	void setExpression(const char* expression);

	///Return the 'answer' to an expression. I.e, if the expression is (10+5)/3 we return 5.
	/// If there is a division or percent by 0 somewhere in the expression, then we throw an error.
	///If the expression param is nullptr, then the function evalutes this->expression. If it isn't, then the function evaluates the expression param.
	/// This is used because sometimes, for test cases specifically, it is somewhat more convenient to just use the function like it's a static function and have it evaluate something else instead of the object caller's expression.
	/// But other times, it is exactly the object caller's expression that needs to be evaluated.
	/// This is the same for all the other function with expression that has a default value of nullptr
	BigNumber evaluateExpression(const char* expression = nullptr) const;

	///Check if expression is valid.
	///If the expression param is nullptr, then the function uses this->expression. If it isn't, then the function uses the expression param.
	/// This is used because sometimes, for test cases specifically, it is somewhat more convenient to just use the function like it's a static function and have it use something else instead of the object caller's expression.
	/// But other times, it is exactly the object caller's expression that needs to be used.
	/// This is the same for all the other function with expression that has a default value of nullptr
	bool expressionIsValid(const char* expression = nullptr) const;

	///Check if expression template is valid.
	bool expressionTemplateIsValid(const char* expressionTemplate) const;

	///Randomly generate a new expression template without any restrictions. 
	///This works by calling the other overload of this function for all allowed operators of the class, which are set via the constant member EXPRESSION_OPERATORS.
	char* generateExpressionTemplate() const;

	///Randomly generate a new expression template with certain conditions. 
	/// The allowed operators decides which operators are allowed to appear in the generated expression. Each operator is a single char from the allowedOperators string.
	///The string does not include brackets. Those are generated seperately
	char* generateExpressionTemplate(const char* allowedOperators) const;

	///Get the expression template for an expression.
	///If the expression param is nullptr, then the function uses this->expression. If it isn't, then the function uses the expression param.
	/// This is used because sometimes, for test cases specifically, it is somewhat more convenient to just use the function like it's a static function and have it use something else instead of the object caller's expression.
	/// But other times, it is exactly the object caller's expression that needs to be used.
	/// This is the same for all the other function with expression that has a default value of nullptr
	char* getExpressionTemplate(const char* expression = nullptr) const;

	///Get the expression template for an expression. Works by calling the other overload of this function for expression.getExpression();
	///If the expression param is nullptr, then the function uses this->expression. If it isn't, then the function uses the expression param.
	/// This is used because sometimes, for test cases specifically, it is somewhat more convenient to just use the function like it's a static function and have it use something else instead of the object caller's expression.
	/// But other times, it is exactly the object caller's expression that needs to be used.
	/// This is the same for all the other function with expression that has a default value of nullptr
	char* getExpressionTemplate(const BigNumberExpression& expression) const;

	///Randomly generates a complete expression from an expression template
	char* generateExpressionFromTemplate(const char* expressionTemplate) const;

	///Randomly generates a new expression. This works by calling the other overload of this function with all allowed operators via the constant EXPRESSION_OPERATORS
	void generateExpression();

	///Generate a new expression with certain conditions. The allowed operators string.
	///The allowed operators decides which operators are allowed to appear in the generated expression. Each operator is a single char from the allowedOperators string.
	void generateExpression(const char* allowedOperators);

	/// <summary>
	/// This function get the 2 expressions, buts them in brackets each and then concats them with an operator and returns the result.
	/// For example: BigNumberExpression a(15+5); BigNumberExpression b(30-20); BigNumberExpression c = a / b ==> c.evaluateExpression() == BigNumber(2);
	/// This function is used for all the operators where it makes sense to use it. Aka, +, +=, -, -=, *, *=, /, /=;
	/// </summary>
	/// <param name="thisExpression"></param>
	/// <param name="otherExpression"></param>
	/// <param name="concatOperator"></param>
	/// <returns></returns>
	char* concatExpressionsWithOperator(const char* thisExpression, const char* otherExpression, const char* concatOperator) const;

	/// <summary>
	/// This evaluated the expressions and compares their values exactly like BigNumber does. This is how I've implemented the code as well. return this->evaluateExpression() == other.evaluateExpression();
	/// All the other comparative operators work the same
	/// </summary>
	/// <param name="other"></param>
	/// <returns></returns>
	bool operator == (const BigNumberExpression& other) const;
	bool operator != (const BigNumberExpression& other) const;
	bool operator < (const BigNumberExpression& other) const;
	bool operator <= (const BigNumberExpression& other) const;
	bool operator > (const BigNumberExpression& other) const;
	bool operator >= (const BigNumberExpression& other) const;

	///Operator arithmetic
	BigNumberExpression operator+(const BigNumberExpression& other) const;
	BigNumberExpression& operator+=(const BigNumberExpression& other);

	BigNumberExpression operator-(const BigNumberExpression& other) const;
	BigNumberExpression& operator-=(const BigNumberExpression& other);

	BigNumberExpression operator*(const BigNumberExpression& other) const;
	BigNumberExpression& operator*=(const BigNumberExpression& other);

	BigNumberExpression operator/(const BigNumberExpression& other) const;
	BigNumberExpression& operator/=(const BigNumberExpression& other);

	BigNumberExpression operator%(const BigNumberExpression& other) const;
	BigNumberExpression& operator%=(const BigNumberExpression& other);

	///Reading and outputting expressions to console
	friend std::istream& operator>> (std::istream& is, BigNumberExpression& expression);
	friend std::ostream& operator<< (std::ostream& is, const BigNumberExpression& expression);

	///Reading  expressions to text file. When reading, read an expression per line
	friend std::ifstream& operator>> (std::ifstream& is, BigNumberExpression& expression);
	///Outputting expressions to text file. When outputting, output an expression and then add "={answer}", where {answer} is obviously the evaluated expression
	friend std::ofstream& operator<< (std::ofstream& os, const BigNumberExpression& expression);
};

