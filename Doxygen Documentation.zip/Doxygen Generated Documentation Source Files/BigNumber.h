#pragma once

#include<iostream>
#include<fstream>

/// <summary>
/// This is used for forward declaration, since the BigNumberDivisionResults depends on BigNumber, but BigNumber also depends on BigNumberDivisionResults
/// </summary>
class BigNumberDivisionResult;
/// <summary>
/// This is the BigNumber class. The aim of this class is to be able to use it like a normal int, while also being able to use much larger numbers than the conventional
/// long long int even. I.e, to be able to do the following 
/// 1111111111111111111111111111111111111111111111 + 1111111111111111111111111111111111111111111111 = 2222222222222222222222222222222222222222222222;
/// 
/// </summary>
class BigNumber
{
private:
	/// <summary>
	/// This is the default capacity for the number array when the default constructor is called.
	/// </summary>
	const int INIT_CAPACITY = 20;

	/// <summary>
	/// This is the actual capacity of the number array.
	/// </summary>
	size_t capacity;
	/// <summary>
	/// This is the size of the number in the array. I.e, the number of digits that the BigNumber has. I originally didn't use null-terminated strings and had to track this.
	/// However, I later reworked this part of the code and now the number array should always be properly null terminated. This means that I can use strlen(number) to check for the digits count instead.
	/// So this is technically not needed. But it is used in a lot of parts of the code and I can't be bothered to change it. So it's left there for historic reasons, let's say.
	/// </summary>
	size_t size;
	///This array holds the digits of the BigNumber, stored in reverse. Yes, the number 123 inside the array is stored as 321. 
	/// I made it like this because I thought it would make things like the addition or multiplication easier since you wouldn't have to move all of the digits in the array back to add one or more digits to the front.
	/// But in reality, I had to reverse the string anyway when doing the division, since the division is done front to back. And I also later made the StringManip functions and made the strings null-terminated. 
	/// This made everything so much easier that now I don't think I need to store the number in reverse. But I can't be bother to change this so I left it as is because it works.
	char* number;
	// This sign of the number. 1 if positive, -1 if negative, 0 if the BigNumber=0
	int sign;

	/// <summary>
	/// This function copies other. It is used in both the =operator function and the constructor. The difference is that the copy constructor calls the default constructor beforehand.
	/// Otherwise, the copy function will try to delete the number array before it copies the number array of other, which will result in an error because the number array isn't even initialized in the first place.
	/// </summary>
	/// <param name="other"></param>
	void copy(const BigNumber& other);
	/// <summary>
	/// This function changes the number array to the given number array. It makes a deep copy, i.e. it doesn't just reassign the pointer of this->number to the number parameter.
	/// This function also changes, as a byproduct, the size and capacity of this. The size is set to the digits count of the number param, and the capacity is that + 1, because 
	/// The number arrays needs to end with a terminating char('\0')
	/// </summary>
	/// <param name="number"></param>
	void changeNumber(const char* number);
	///Adds 2 numbers together by absolute value and return a new number that is their sum.
	///The areNegative param determines if the function should invert the sign of the result before returning it. This is used when we are adding 2 negative numbers together.
	///This function is called inside the +operator and the -operator functions.
	///In the +operator function, it is called when the 2 numbers are both positive or negative.
	///In the -operator function, it is called when we have A-B, where A is positive and B is negative. Or in cases A-B, where A is negative and B is positive.
	BigNumber addAndReturn(const BigNumber& thisNumber, const BigNumber& other, bool areNegative) const;
	///Subtracts 2 numbers by absolute value and returns a new number that is their difference.
	///This function is called inside the +operator and the -operator functions.
	///In the +operator function, it is called when the 2 numbers are with different signs.
	///In the -operator function, it is called when the 2 numbers are with different signs.
	BigNumber subtractAndReturn(const BigNumber& thisNumber, const BigNumber& other) const;
	/// <summary>
	/// Divide 2 numbers and return the quotient and leftover of the division as a result.
	/// This function is called inside the /operator and the %operator. Inside those operators, once the functions returns the quotient and leftover, we return what is appropriate.
	/// This is done because to do the /operator, you essentially need to be able to do the %operator as well. Hence why I let one function do the hard part and just return both at the same time.
	/// </summary>
	/// <param name="other"></param>
	/// <returns></returns>
	BigNumberDivisionResult divideAndReturn(const BigNumber& other) const;

public:
	/**
	* @brief Default constructor, sets the value of the number to 0
	*/
	BigNumber();

	/**
	* @brief Copy constructor, sets the value of the number to the given BigNumber
	*/
	BigNumber(const BigNumber& other);

	/**
	 * @brief Constructor with parameter
	 *
	 * @param number a number represented as a string
	 */
	BigNumber(const char* number);

	/**
	 * @brief Constructor with parameter
	 *
	 * @param number a number represented as an integer
	 */
	BigNumber(long long int number);

	///This is the custom destructor needed to delete the number array
	~BigNumber();

	///Get the sign of the number
	int getSign();

	///Assigment operator
	BigNumber& operator = (const BigNumber& other);

	/// == operator, which works exactly the same as for integers
	bool operator == (const BigNumber& other) const;
	/// != operator, which works exactly the same as for integers
	bool operator != (const BigNumber& other) const;
	/// < operator, which works exactly the same as for integers
	bool operator < (const BigNumber& other) const;
	/// <= operator, which works exactly the same as for integers
	bool operator <= (const BigNumber& other) const;
	/// > operator, which works exactly the same as for integers
	bool operator > (const BigNumber& other) const;
	/// >= operator, which works exactly the same as for integers
	bool operator >= (const BigNumber& other) const;

	/// <summary>
	/// Returns whether or not the number is 0, i.e. if it's sign is == 0. 
	/// </summary>
	/// <returns></returns>
	bool isZero() const;
	/// <summary>
	/// Compares two numbers by absolute value
	/// </summary>
	/// <param name="other"></param>
	/// <returns></returns>
	bool greaterThanOrEqualsAbsolute(const BigNumber& other) const;

	/// += operator, which works exactly the same as for integers
	/// Works by calling *this = *this + other; return *this;   It might be slower, than doing it the other way around, i.e using the += function to define the + function. But I don't care.
	/// The same holds true for the other operators.
	BigNumber& operator += (const BigNumber& other);
	/// + operator, which works exactly the same as for integers.
	/// This here calls the addAndReturn or subtractAndReturn functions, depending on the cases. It also checks easily solveable edge cases beforehand.
	BigNumber operator + (const BigNumber& other) const;
	/// -= operator, which works exactly the same as for integers.
	/// Works by calling *this = *this - other; return *this;
	BigNumber& operator -= (const BigNumber& other);
	/// - operator, which works exactly the same as for integers.
	/// This here calls the addAndReturn or subtractAndReturn functions, depending on the cases. It also checks easily solveable edge cases beforehand.
	BigNumber operator - (const BigNumber& other) const;
	/// *= operator, which works exactly the same as for integers.
	///Works by calling *this = *this * other; return *this;
	BigNumber& operator *= (const BigNumber& other);
	/// * operator, which works exactly the same as for integers.
	/// Unlike with all the other operators, this one holds all of it's logic inside the actual function, because that logic cannot be reused anywhere anyway.
	BigNumber operator * (const BigNumber& other) const;

	///Reading shit from console
	friend std::istream& operator>> (std::istream& is, BigNumber& other);
	///Outputting to console
	friend std::ostream& operator<< (std::ostream& os, const BigNumber& other);

	///Outputting shit to text file
	friend std::ofstream& operator<< (std::ofstream& os, const BigNumber& other);

	///Returns the number but with commas after every third digit, for better viewer experience
	const char* getNumber() const;
	/// <summary>
	/// Returns the number without any fancy commas.
	/// </summary>
	/// <returns></returns>
	const char* getNumberRaw() const;
	/// <summary>
	/// Prints out the number with fancy commas to the console
	/// </summary>
	void printOutNumber() const;
	/// <summary>
	/// Prints out the number without fancy commas to the console
	/// </summary>
	void printOutNumberRaw() const;

	// Optional
	///Works by calling *this = *this / other; return *this;
	BigNumber& operator /= (const BigNumber& other);
	/// <summary>
	/// This here calls the divideAndReturn function and then gets the quotient and returns it
	/// </summary>
	/// <param name="other"></param>
	/// <returns></returns>
	BigNumber operator / (const BigNumber& other) const;
	/// <summary>
	/// Works by calling *this = *this % other; return *this;
	/// </summary>
	/// <param name="other"></param>
	/// <returns></returns>
	BigNumber& operator %= (const BigNumber& other);
	/// <summary>
	/// This here calls the divideAndReturn function and then gets the leftover and returns it
	/// </summary>
	/// <param name="other"></param>
	/// <returns></returns>
	BigNumber operator % (const BigNumber& other) const;
	///--BigNumber. Works the same as for ints
	BigNumber& operator--();
	///BigNumber--. Works the same as for ints
	BigNumber operator--(int);
	///++BigNumber. Works the same as for ints
	BigNumber& operator++();
	///BigNumber++. Works the same as for ints
	BigNumber operator++(int);
};
