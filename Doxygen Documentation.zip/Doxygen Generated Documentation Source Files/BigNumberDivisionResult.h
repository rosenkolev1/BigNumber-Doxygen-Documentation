#pragma once

#include<iostream>

/// <summary>
/// This is used for forward declaration, since the BigNumberDivisionResults depends on BigNumber, but BigNumber also depends on BigNumberDivisionResults
/// </summary>
class BigNumber;
/// <summary>
/// This class holds the information from a division with bigNumber. Inside the / and % operator function for BigNumber, I call another function that divides the 2 numbers and returns an object of class
/// BigNumberDivisionResult, which stored the divisionQuotient and the leftOver. Then, inside the / or % operator function, I retrieve the necessary data(quotient or leftover).
/// and return it as a result
/// </summary>
class BigNumberDivisionResult
{
private:
	///The quotient part of the division. Quotient means the result of the division
	BigNumber& divisionQuotient;
	///The leftover (%) part of the division
	BigNumber& divisionLeftover;
public:
	/// <summary>
	/// The only constructor for this class, which does exactly what it may look like
	/// </summary>
	/// <param name="divisionQuotient"></param>
	/// <param name="divisionLeftover"></param>
	BigNumberDivisionResult(BigNumber& divisionQuotient, BigNumber& divisionLeftover);
	/// <summary>
	/// This does exactly what you may think it does. It get the quotient number, as a constant, i.e. for read-only access
	/// </summary>
	/// <returns></returns>
	const BigNumber& getQuotient() const;
	/// <summary>
	/// This does exactly what you may think it does. It get the leftOver number, as a constant, i.e. for read-only access
	/// </summary>
	/// <returns></returns>
	const BigNumber& getLeftover() const;
};


