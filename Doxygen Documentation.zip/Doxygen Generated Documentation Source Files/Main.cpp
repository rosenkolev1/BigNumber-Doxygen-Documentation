// Main.cpp : This file contains the 'main' function. Program execution begins and ends there.
//

#include <iostream>
#include <fstream>
#include "BigNumber.h"
#include "BigNumberDivisionResult.h"
#include "BigNumberTests.h"
#include "BigNumberExpression.h"
#include "BigNumberExpressionTests.h"
#include "BigNumberEquationTests.h"

/// <summary>
/// This is the main function. The program start from here.
/// This function runs all the tests while also opening the connection to the tests files, which store the information from the those test, should we decide to pass said streams as arguments to the 
/// test functions.
/// </summary>
/// <returns></returns>
int main()
{
    /// <summary>
    /// The equation tests stream to file
    /// </summary>
    /// <returns></returns>
    std::ofstream osEquationTests(BigNumberEquationTests::OUTPUTFILE_NAME, std::ios::app);
    /// <summary>
    /// The expression tests stream to file
    /// </summary>
    /// <returns></returns>
    std::ofstream osExpressionTests(BigNumberExpressionTests::OUTPUTFILE_NAME, std::ios::app);
    /// <summary>
    /// The bigNumber tests stream to file
    /// </summary>
    /// <returns></returns>
    std::ofstream osBigNumberTests(BigNumberTests::OUTPUTFILE_NAME, std::ios::app);

    ///BigNumber tests
    BigNumberTests::runTests(std::cout);

    ///BigNumberExpression tests
    BigNumberExpressionTests::runTests(std::cout);

    ///BigNumberEquations tests
    BigNumberEquationTests::runTests(std::cout);

    ///Closing the database connection
    osEquationTests.close();
    ///Closing the database connection
    osExpressionTests.close();
    ///Closing the database connection
    osBigNumberTests.close();
}